[hr]
[center][color=teal][size=16pt][b]Karma Smite Disable[/b][/size][/color]
[u](For SMF 2.0.x)[/u]
Mod by xPandax | [url=http://custom.simplemachines.org/mods/index.php?action=profile;u=158159]Other Mods[/url] by xPandax
[/center]
[hr]
[center][url=http://custom.simplemachines.org/mods/index.php?mod=3761]Link to Mod[/url] | [url=http://www.simplemachines.org/community/index.php?topic=508754.0]Support Thread for this Mod[/url][/center]


[color=purple][size=12pt][b]Features[/b][/size][/color]
This mod disables 'Karma Smite' option. In other words, users can see & use only the 'Applaud Karma' option.


[color=purple][size=12pt][b]How-To[/b][/size][/color]
NA.


[color=purple][size=12pt][b]Supported Themes[/b][/size][/color]
Works on all the themes without any custom edits!


[color=purple][size=12pt][b]Supported SMF Versions[/b][/size][/color]
Tested on fresh installation of 2.0.4.


[color=purple][size=12pt][b]Supported Languages[/b][/size][/color]
NA.


[color=purple][size=12pt][b]Support[/b][/size][/color]
If you need support with this mod, please use the [url=http://www.simplemachines.org/community/index.php?topic=508754.0]Support Thread for this Mod[/url].

 
[color=purple][size=12pt][b]Changelog[/b][/size][/color]
[b]v1.0[/b] - Initial release.


[hr][center][color=purple][size=14pt][b]License[/b][/size][/color]

This is free and unencumbered mod released into the public domain. For more information, see [url=http://unlicense.org/]http://unlicense.org/[/url] or the accompanying UNLICENSE file.
[/center]
